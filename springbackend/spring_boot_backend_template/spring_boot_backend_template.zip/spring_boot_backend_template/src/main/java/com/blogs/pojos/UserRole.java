package com.blogs.pojos;

public enum UserRole {

	ADMIN,CUSTOMER,MECHANIC
}
