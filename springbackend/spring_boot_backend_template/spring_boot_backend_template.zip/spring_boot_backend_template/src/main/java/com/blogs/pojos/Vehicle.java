package com.blogs.pojos;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString(exclude = "user") // Exclude user to avoid recursion in bidirectional relationship
@Entity
@Table(name = "Vehicles")
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Vehicle_ID")
    private Long vehicleId;

    @Column(name = "Make", nullable = false, length = 50) // Make cannot be null
    private String make;

    @Column(name = "Model", nullable = false, length = 50) // Model cannot be null
    private String model;

    @Column(name = "Year", nullable = false) // Assuming this is a numeric year
    private Integer year;

    @Column(name = "Registration_Number", nullable = false, unique = true, length = 20) // Unique registration number
    private String registrationNumber; // Renamed to camelCase

    @ManyToOne
    @JoinColumn(name = "User_ID", nullable = false) // Mandatory relationship with User
    private User user;

	
    
}
