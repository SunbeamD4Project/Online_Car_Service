package com.blogs.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.blogs.pojos.Vehicle;

@Repository
public interface Vehicle_Reposirtory extends JpaRepository<Vehicle, Long>{

}